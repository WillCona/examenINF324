<?php
     /*
     no te olvides el puerto jejeje
     */
     $con = mysqli_connect('localhost:33065','inf324','123456');
     mysqli_select_db($con,'worflow2');
?>