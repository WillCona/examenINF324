Documentos<br>
<input type="hidden" name="id" value=""/> <br>
Nombre Completo :
<input type="text" name="nombrecompleto" value="<?php echo $nombrecompleto;?>"/> <br>
Certificado de nacimiento : 
<input type="text" name="cnacimiento" value=""/> <br>
Carnet de identidad : 
<input type="text" name="cidentidad" value=""/> <br>
