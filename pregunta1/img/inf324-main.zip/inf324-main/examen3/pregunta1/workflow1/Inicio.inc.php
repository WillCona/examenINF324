Inicio de flujo<br>
Introduzca su ID: 
<input type="text" name="id" values=""/> <br>