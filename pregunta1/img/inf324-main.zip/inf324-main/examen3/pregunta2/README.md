### Pregunta 2
![](./imagenes/pregunta3-1.png)