# Primer Examen

9. Implemente un Micro Servicios sobre USUARIOS con PHP que permita altas, bajas y cambios en PERSONA
![](../imgs/pregunta9/get.png)
![](../imgs/pregunta9/post.png)
![](../imgs/pregunta9/puth.png)
![](../imgs/pregunta9/delete.png)


