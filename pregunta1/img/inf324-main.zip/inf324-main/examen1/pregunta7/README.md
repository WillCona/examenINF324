# Primer Examen

7. Implemente un WEB SERVICE en VISUAL STUDIO que permita altas, bajas y cambios en PERSONA, usando la misma en aplicación WindowsForm.
![](../imgs/pregunta7/1.png)
![](../imgs/pregunta7/2.png)
![](../imgs/pregunta7/3.png)


