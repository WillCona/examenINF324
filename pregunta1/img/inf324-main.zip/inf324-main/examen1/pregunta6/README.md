# Primer Examen

6. Implemente las altas, bajas y cambios de la tabla PERSONA mediente Codeigniter.
![](../imgs/pregunta6/1.png)

