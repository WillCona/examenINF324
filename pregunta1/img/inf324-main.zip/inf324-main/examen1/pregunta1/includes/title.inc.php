<div class="row">
    <div class="col-lg-12">
        <div class="section-title text-center">
            <div class="title-text">
                <h2>Facultad de Ciencias Puras y Naturales</h2>
            </div>
        </div>
    </div>
</div>