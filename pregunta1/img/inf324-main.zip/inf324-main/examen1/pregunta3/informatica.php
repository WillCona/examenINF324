<!DOCTYPE html>
<html lang="en">

<?php
session_start();
include "./includes/head.inc.php";
include "./includes/isLogin.php";
?>

<body>
    <div class="event-schedule-area-two bg-color pad100">
        <div class="container">
            <?php
            include "./includes/title.inc.php";
            ?>

            <div class="row">
                <div class="col-lg-12">
                    <b>Carrera de Informatica </b> <br>
                    <br>
                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit excepturi repudiandae consequuntur cumque aut quo voluptate, est assumenda vero nam architecto harum voluptas commodi porro minima neque rem aperiam laboriosam!
                    </p>

                    <p>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit excepturi repudiandae consequuntur cumque aut quo voluptate, est assumenda vero nam architecto harum voluptas commodi porro minima neque rem aperiam laboriosam!
                    </p>
                </div>
            </div>

        </div>
    </div>
    <?
    include "./includes/head.inc.php";
    ?>
</body>

</html>