# Primer Examen

3. Genere una pantalla de acceso (CSS y PHP) con la base de datos, controlando en las demás pantallas mediante sesiones.

![](../imgs/pregunta3/1.png)

