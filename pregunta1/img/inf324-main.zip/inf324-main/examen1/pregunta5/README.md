# Primer Examen
5. Con el rol DIRECTOR se puede visualizar por departamento la media de notas, con PHP (case-when).
![](../imgs/pregunta5/1.png)
