<?php
session_start();
include "conexion.inc.php";
echo '<pre>';
print_r($_POST);
echo '</pre>';
