<!DOCTYPE html>
<html>
<head>
  <title>Proceso en curso</title>
  <!-- Agrega los enlaces a los archivos CSS de Bootstrap -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
  <div class="container">
    <h1>El proceso ha iniciado</h1>
    <p>Haga clic en "Siguiente" para continuar:</p>
  </div>

  <!-- Agrega los enlaces a los archivos JS de Bootstrap y jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
