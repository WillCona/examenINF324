<div class="container mt-5">
  <div class="card bg-light border-0 p-0 mx-auto" style="max-width: 1500;">
    <h1 class="text-primary mb-12">Haga Click en siguiente para iniciar el proceso de inscripcion</h1>
  </div>
</div>
<br>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
