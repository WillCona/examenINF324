INF 324 2do Parcial

